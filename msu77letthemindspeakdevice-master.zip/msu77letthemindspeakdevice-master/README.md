# msu77letthemindspeakdevice
msu77devices. mind speak,personal speak and silent speak
